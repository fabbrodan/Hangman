export {default as background} from './background.png';
export {default as gallow0} from './gallow.png';
export {default as gallow1} from './gallow-1.png';
export {default as gallow2} from './gallow-2.png';
export {default as gallow3} from './gallow-3.png';
export {default as gallow4} from './gallow-4.png';
export {default as gallow5} from './gallow-5.png';
export {default as gallow6} from './gallow-6.png';